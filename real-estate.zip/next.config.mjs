/** @type {import('next').NextConfig} */
const nextConfig = {
  // output: 'export',
  basePath:"/elrealestate",
 
};

export default nextConfig;
