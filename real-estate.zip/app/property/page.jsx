'use client';

import dynamic from 'next/dynamic';
import React from 'react';
import { api } from '@/app/utils/api';
import { url } from '@/app/utils/urls';
import { useRouter } from 'next/navigation';
const PropertyComponent = dynamic(() => import("@/app/components/property"))

const Property = () => {
  const [loading, setLoading] = React.useState(true)
  const [properties, setProperties] = React.useState([])
  const [types, setTypes] = React.useState([])
  const [filters, setFilters] = React.useState({})
  const [totalData, setTotalData] = React.useState(0)
  const [currentPage, setCurrentPage] = React.useState(1);
  const [status, setStatus] = React.useState(0)
  const [cities,setCities] = React.useState([])
  const router = useRouter();
  let routes = {
    page:1,
    status:""
  }
  const handlePageChange = (page, offset) => {
    setCurrentPage(page.selected + 1);
    router.push(`/property?page=${page.selected + 1}`)
  };
  const handleStatus = (id, title) => {
    router.push(`/property?status=${title}`)
    setStatus(id)

  }
  const getProprties = async () => {
    try {
      console.log(typeof(status))
      const body = {
        sorting:1,
        listing_status: status
      }
      const data = await api.Post(`${url.PROPERTIES}?page=${currentPage}`, body)
      if (data) {
        setProperties(data.data.data)
        console.log(data)
        setTotalData(data.records_count)
      }

    } catch (error) {
      console.log(error)
    }
  }

  const getCities = async () => {
    try {
      const data = await api.Get(url.CITIES)
      if (data) {
        setCities(data.data)
      }
    } catch (error) {
      console.log(error)
    }
  }

  const getTypes = async () => {
    try {
      const data = await api.Get(url.PROPERTY_TYPES)
      if (data) {
        setTypes(data.data)
      }
    } catch (error) {
      console.log(error)
    }
  }
  const getFilters = async () => {
    try {
      const data = await api.Get(url.FILTERS)
      if (data) {
        setFilters(data.data)

      }
    } catch (error) {
      console.log(error)
    }
  }

  React.useEffect(() => {
    getFilters()
    getTypes()
    getCities()
  }, [])
  React.useEffect(() => {
    getProprties()
    window.scrollTo({ top: 0, behavior: "smooth" })
  }, [currentPage, status])

  return (
    <>

      <PropertyComponent
        properties={properties}
        types={types}
        filters={filters}
        totalProperties={totalData}
        handlePageChange={handlePageChange}
        handleStatus={handleStatus}
        cities={cities}
        status={status}

      />
    </>

  )
}

export default Property